local hp_ = 1

local m = models.model.root

function events.tick()
    hp_ = player:getHealth() / player:getMaxHealth()

    if hp_ >= 1 then
        do return end
    end

    thresholdOff(m.LeftArm, hp_, 0.7)

    thresholdOff(m.Body, hp_, 0.4)

    thresholdOff(m.Head, hp_, 0.2)

    if hp_ <= 0.1 then
        m.Head:setRot(0, 0, 30)
    else
        m.Head:setRot(0, 0, 0)
    end
end

function thresholdOff(part, value, threshold)
    if value <= threshold then
        part:setSecondaryRenderType("NONE")
    else
        part:setSecondaryRenderType("EYES")
    end
end