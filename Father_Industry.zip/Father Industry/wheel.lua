local defaultSmoke = true
local defaultSmog = true

SmokeEnabled = defaultSmoke
SmogEnabled = defaultSmog

function pings.toggleSmoke(isToggled)
    SmokeEnabled = isToggled
end

function pings.toggleSmog(isToggled)
    SmogEnabled = isToggled
end

local IndustryPage1 = action_wheel:newPage()

local SmokeToggleAction = IndustryPage1:newAction()
SmokeToggleAction:toggled(true)
SmokeToggleAction:onToggle(pings.toggleSmoke)
SmokeToggleAction:setToggleItem("minecraft:charcoal")
SmokeToggleAction:setItem("minecraft:barrier")
SmokeToggleAction:setTitle("Toggle Smoke")
SmokeToggleAction:setToggled(defaultSmoke)

local SmogToggleAction = IndustryPage1:newAction()
SmogToggleAction:toggled(true)
SmogToggleAction:onToggle(pings.toggleSmog)
SmogToggleAction:setToggleItem("minecraft:campfire")
SmogToggleAction:setItem("minecraft:barrier")
SmogToggleAction:setTitle("Toggle Ground Smog")
SmogToggleAction:setToggled(defaultSmog)

action_wheel:setPage(IndustryPage1)