vanilla_model.PLAYER:setVisible(false)
vanilla_model.ARMOR:setVisible(false)
vanilla_model.HELMET_ITEM:setVisible(true)
vanilla_model.CAPE:setVisible(false)

local rotClock = 0
local plrSpeed = 1
local tick = 0
local smogParticle = "minecraft:campfire_cosy_smoke"
local smokeParticle = "minecraft:smoke"
local bubbleParticle = "minecraft:bubble"

function events.tick()
    plrSpeed = 1 + (plrSpeed - 1 + player:getVelocity():length() * 5) * 0.85
    rotClock = rotClock + plrSpeed
    tick = tick + 1

    if player:isInvisible() then
        do return end
    end

    local l
    if world.getBlockState(models.model.root.Body.LeftSmokeStack.SmokeEmitter2:partToWorldMatrix():apply()):getID() == "minecraft:water" then
        l = bubbleParticle
    else
        l = smokeParticle
    end

    local r
    if world.getBlockState(models.model.root.Body.RightSmokeStack.SmokeEmitter1:partToWorldMatrix():apply()):getID() == "minecraft:water" then
        r = bubbleParticle
    else
        r = smokeParticle
    end

    if tick % 3 == 0 and SmogEnabled and player:isOnGround() and not player:isInWater() then
        particles:newParticle(smogParticle, player:getPos())
    end

    if tick % 3 == 0 and SmokeEnabled then
        local pos = models.model.root.Body.RightSmokeStack.SmokeEmitter1:partToWorldMatrix():apply()
        particles:newParticle(l, pos.x, pos.y, pos.z)
        pos = models.model.root.Body.LeftSmokeStack.SmokeEmitter2:partToWorldMatrix():apply()
        particles:newParticle(r, pos.x, pos.y, pos.z)
    end
end

function events.render(delta, context)
    models.model.root.Body.gear:setRot(0, 0, rotClock + plrSpeed * delta)
    models.model.root.LeftArm.gear:setRot(-90, rotClock + plrSpeed * delta, -90)
end